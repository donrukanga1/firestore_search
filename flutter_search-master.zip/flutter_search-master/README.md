# flutter_search

Firestore Instant Search in Flutter 🔍

***Updating readme soon*** 🔥

